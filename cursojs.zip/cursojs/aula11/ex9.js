var pais = 'Brasil'

console.log(`Vivendo em ${pais}`)

if (pais == 'Brasil') {
    console.log(`Vc é br`)
} else {
    console.log(`Vc é estrangeiro`)
}