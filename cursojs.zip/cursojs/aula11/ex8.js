var vel = 12
console.log(`A velocidade do seu carro é ${vel} km`)

if(vel > 60) { //condição simples
    console.log(`Vc foi multado!`)
} else {
console.log(`Use sempre cinto!`)
}