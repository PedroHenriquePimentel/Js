function tabuada() {
    let num = document.getElementById('idnum')
    let tabu = document.getElementById('idtabu')

    if(num.value.length == 0) {
        alert('Pfv, digite um nº')
    } else {
        let n = Number(num.value)
        let c = 1
        tabu.innerHTML = ''
        while(c <= 10){
            let item = document.createElement('option')
            item.text = `${n} x ${c} = ${n * c} `
            item.value = ``
            tabu.appendChild(item)
            c++
        }
    }
}