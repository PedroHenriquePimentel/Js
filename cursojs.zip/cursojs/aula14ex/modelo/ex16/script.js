function botao() {
    let inicio = document.getElementById('ini');
    let fim = document.getElementById('fim');
    let passo = document.getElementById('passo');
    let resultado = document.getElementById('contagem');

    if (inicio.value.length == 0 || fim.value.length == 0 || passo.value.length == 0) {
        alert('[ERRO] Faltam dados!');
    } else {
        resultado.innerHTML = 'Contando...'
        let ini = Number(inicio.value)
        let fi = Number(fim.value)
        let pas = Number(passo.value)
        if(pas <= 0) {
            alert(`Passo invalido! Considerando passo 1`)
            pas = 1
        }
        if(ini < fi) {
        for(let contagem = ini; contagem <= fi; contagem += pas) {
            resultado.innerHTML += `${contagem} \u{1F449} `
        }
        resultado.innerHTML += `\u{1F3C1}`
      } else {
        for(let contagem = ini; contagem >= fi; contagem -= pas ) {
            resultado.innerHTML += `${contagem} \u{1F449} `
        }
        resultado.innerHTML += `\u{1F3C1}`
      }
    }
}