console.log(`Vai cmç`)
for(var c=1; c<=4; c++ ) {
    console.log(`${c}`) 
}
console.log(`Fim!`)