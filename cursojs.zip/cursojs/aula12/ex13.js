var agora = new Date()
var diasem = agora.getDay()
/* 0 = dom
   1 = seg
   2 = ter
   3 = qua
   4 = qui
   5 = sex
   6 = sáb 
   */
//console.log( diasem)

switch(diasem) {
    case 0:
    console.log(`Domingo`)
    break
    case 1: 
    console.log(`Segunda`)
    break
    case 2: 
    console.log(`Terça`)
    break
    case 3:
    console.log(`Quarta`)
    break
    case 4: 
    console.log(`Quinta`)
    break
    case 5: 
    console.log(`Sexta`)
    break
    case 6:
    console.log(`Sábado`)
    break
    default:
    console.log(`Dia invalido`)
    break
}