var hora = 1
console.log(`São ${hora}h`)

if(hora < 12 && hora > 5) {
    console.log(`Bom dia`)
} else if(hora <= 18 && hora >= 12) {
    console.log(`Boa Tarde`)
} else if(hora >= 19 && hora <= 23) {
    console.log(`Boa Noite`)
} else {
    console.log(`Boa madrugada`)
}