let num = [0, 1, 2, 3, 4]
for(let pos in num ) {
    console.log(`${num[pos]}`)
}
