let valores = [8, 1, 2 , 3]

for(let pos = 0; pos < valores.length; pos++) {
    console.log(`${valores[pos]}`)
}