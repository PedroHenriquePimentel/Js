let num = [7, 6]
console.log(` o vetor tem ${num.length} posições`)
let pos = num.indexOf(7)
console.log(`1 valor é ${num[0]}`)
if(pos == -1) {
    console.log(`O valor n foi encontrado`)
} else {
console.log(`mostrando o indexOF funfando: ${pos}`)
}