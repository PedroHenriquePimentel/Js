let num = [7, 6]
num.push(1)
num.sort()
console.log(` o vetor tem ${num.length} posições`)
console.log(`1 valor é ${num[0]}`)