function carregar() {
var msg = document.getElementById('msg')
var foto = document.getElementById('imagem')
var hora = new Date().getHours()
msg.innerHTML = `Agora são ${hora}h`

if(hora>= 6 && hora < 12) {
    foto.src = `manha.jpg`
    document.body.style.background = "yellow"
} else if(hora >= 12 && hora < 18 ) {
    foto.src = `tarde.jpg`
    document.body.style.background = "72, 72, 206"
} else {
    foto.src = `noite.jpg`
    document.body.style.background = "black"
}
} 