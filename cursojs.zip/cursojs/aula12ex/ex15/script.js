function botao() {
    var data = new Date().getFullYear();
    var form = document.getElementById('txtano');
    var res = document.querySelector('div#resultado');

    if (form.value.length == 0 || form.value > data) {
        alert('Verifique os dados e tente novamente!');
    } else {
        var sexfem = document.getElementsByName('radsex');
        var idade = data - form.value;
        var genero = '';
        var img = document.createElement('img');
        img.setAttribute('id', 'foto');

        if (sexfem[0].checked) {
            genero = 'Homem';
            if (idade >= 0 && idade <= 10) {
                img.setAttribute('src', 'bbhomem.jpg');
            } else if (idade > 10 && idade < 22) {
                img.setAttribute('src', 'adolhomem.jpg');
            } else if (idade >= 22 && idade <= 58) {
                img.setAttribute('src', 'guri.jpg');
            } else if (idade > 58 && idade <= 125) {
                img.setAttribute('src', 'idoso.jpg');
            } else {
                alert('Idade fora do intervalo esperado.');
                return;
            }
        } else if (sexfem[1].checked) {
            genero = 'Mulher';
            if (idade >= 0 && idade <= 10) {
                img.setAttribute('src', 'bbmulher.jpg');
            } else if (idade > 10 && idade < 22) {
                img.setAttribute('src', 'adolmulher.jpg');
            } else if (idade >= 22 && idade <= 58) {
                img.setAttribute('src', 'guria.jpg');
            } else if (idade > 58 && idade <= 125) {
                img.setAttribute('src', 'idosa.jpg');
            } else {
                alert('Idade fora do intervalo esperado.');
                return;
            }
        }

        res.style.textAlign = 'center';
        res.innerHTML = `<p>${genero} com ${idade} anos</p>`;
        res.appendChild(img);
    }
}
